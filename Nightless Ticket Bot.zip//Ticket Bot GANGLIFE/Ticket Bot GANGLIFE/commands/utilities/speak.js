const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args, prefix) => {

    if(!message.member.permissions.has('MANAGE_SERVER')){
        const failedEmbed = new Discord.MessageEmbed()
            .setDescription(`U heeft geen rechten om een serverbericht te verzenden!`)
            .setColor("#DD0000")
        return message.channel.send({ embeds: [failedEmbed] })
    }

    message.delete()

    const missingArgs = new Discord.MessageEmbed()
        .setDescription(`U bent vergeten tekst in te voeren! Probeer het opnieuw.\nGebruik: \`${prefix}speak uw-bericht\``)
        .setColor("#DD0000")   

    const text = args.join(" ")
    if(!text){ return message.channel.send({ embeds: [missingArgs] })}

    message.channel.send({ content: text })

}

module.exports.help = {
    name: 'speak',
    aliases: []
}
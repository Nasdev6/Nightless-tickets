const Discord = require('discord.js');
const db = require('quick.db');
const client = require("../index").client
const { Permissions } = require('discord.js');
const moment = require('moment');
const ms = require('ms');
const fs = require('fs')

client.on('guildMemberAdd',  async(member, client, con, guildMember) => {


    const channel = member.guild.channels.cache.find(x => x.id === '955202000243544142')
    if(channel === undefined) return console.log('Je hebt het welkoms kanaal nog niet ingesteld! Om hem in te stellen ga je naar events -> guildMemberAdd.js en pas het ID aan op line 12!');



     let welcomeEmbed = new Discord.MessageEmbed()
            .setColor("#8400b9")
            .setTitle(`Welkom @${member.user.tag}!`)
            .setFooter("Cxsh development - Since 2022 © Alle rechten voorbehouden")
            .setDescription(`Welkom in de Cxsh Development Discord! Hulp nodig, wil je solliciteren of wil je bijvoorbeeld een klacht indienen? Maak dan een ticket aan in: <#955221851863392278>! \n\n**Account Leeftijd:** ${member.user.createdAt.toLocaleString()}`, false)
            .setThumbnail(member.user.displayAvatarURL({dynamic: true }))
      channel.send({ embeds: [welcomeEmbed] })

    
});
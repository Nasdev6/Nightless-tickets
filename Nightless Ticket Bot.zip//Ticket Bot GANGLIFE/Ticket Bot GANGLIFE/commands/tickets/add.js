const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args, prefix) => {

    if(db.get(`ticketApproved_${message.channel.id}`) != true){
        const failedEmbed = new Discord.MessageEmbed()
            .setDescription(`U kunt deze opdracht alleen uitvoeren in een **Ticketkanaal**!`)
            .setColor("#DD0000")
        return message.reply({ embeds: [failedEmbed] })
    }

    const add = message.mentions.roles.first() || message.mentions.members.first() || client.users.cache.find(x => x.id === args[0]) || message.guild.roles.cache.find(x => x.id === args[0])
    message.channel.permissionOverwrites.create(add.id, {VIEW_CHANNEL: true, SEND_MESSAGES: true, ATTACH_FILES: true})

    const succesEmbed = new Discord.MessageEmbed()
        .setAuthor(`Gebruiker(s) toegevoegd`, message.guild.iconURL({ dynamic: true }))
        .setDescription(`${add} is succesvol toegevoegd aan dit ticket!`)
        .setColor("#DD0000")
    message.reply({ embeds: [succesEmbed] })

}

module.exports.help = {
    name: 'add',
    aliases: []
}
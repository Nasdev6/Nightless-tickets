// BLIJF VAN DEZE FILES AF! ER STAAN HIER 0 ERRORS IN EN JE HOEFT HIER VERDER NIKS AAN TOE TE VOEGEN! AANPASSEN OP EIGEN RISICO!
const { Client, Intents, DiscordAPIError } = require('discord.js');
const Discord = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MESSAGE_REACTIONS, Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS], allowedMentions: { parse: ['users', 'roles']} });

const fs = require('fs');
const yaml = require('js-yaml')

function loadFile(file){
    return myFile = yaml.load(fs.readFileSync(`${file}`, 'utf8'))
  }
  

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
client.events = new Discord.Collection();
module.exports.client = client

// COMMAND HANDLER
fs.readdirSync('./commands/').forEach(dir => {
    fs.readdir(`./commands/`, (err, files) => {
        if(err) throw err;

        var jsFiles = files.filter(f => f.split(".").pop() === "js");
        
        jsFiles.forEach(file => {
            var fileGet = require(`./commands/${file}`);

            try {
                client.commands.set(fileGet.help.name, fileGet);
                
                fileGet.help.aliases.forEach(alias => {
                    client.aliases.set(alias, fileGet.help.name);
                })
            } catch (err) {
                return console.log(err);
            }
        });
    });
});

// EVENTS HANDLER
fs.readdirSync(`./events/`).forEach(dir => {
    var jsFiles = fs.readdirSync('./events/').filter(f => f.split(".").pop() === "js");
    jsFiles.forEach(event => {
        const eventGet = require(`./events/${event}`)

        try {
            client.events.set(eventGet.name, eventGet)
        } catch(err) {
            return console.log(err)
        }
    })
})


client.login("OTU1MDQ0Nzc4NzA0MjUyOTg5.Yjb8ww.KKcGQS765Ud9pum0ay6lGVVKlao")

/**********************************************************
 * @INFO
 * This bot is coded by @Mr. Dragon#4025 | https://dev.zentox.net/dc
 * @INFO
 * Work for Milrato Development | https://dev.zentox.net
 * @INFO
 * ZentoxDevelopment © Since 2021 - All Rights Reserved.
 * @INFO
 *********************************************************/
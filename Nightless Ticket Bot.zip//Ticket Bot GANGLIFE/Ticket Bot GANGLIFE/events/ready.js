const Discord = require('discord.js');
const client = require("../index").client
const db = require('quick.db')

client.on('ready', () => {
    client.user.setPresence({ activities: [{ name: `tickets`, type: "WATCHING" }] })
})
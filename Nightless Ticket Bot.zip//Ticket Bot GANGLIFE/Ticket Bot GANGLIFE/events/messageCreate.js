const client = require("../index").client
const Discord = require('discord.js');
const db = require('quick.db');

const moment = require('moment')
const fs = require('fs')

client.on('messageCreate', async message => {

    if(db.get(`ticketApproved_${message.channel.id}`) === true){

        if (message.embeds.length == 0){
    
          fs.appendFile(`./transcripts/transcript-${message.channel.id}.html`, `
          </p><p class="pt-2"></small></p><hr class="bg-dark"></hr></div></div></div><div class="container-fluid bg-light text-black"><div class="row w-50 pt-2 mx-auto"><div class="col w-50"><img src="${message.author.displayAvatarURL()}" class="rounded-circle mr-1 float-left" alt="Profile Picture" width="30px"><h5>${message.author.username}</h5><p class="w-50"><p>${message.content}<br><br><small>${moment().format('LLL')}</small></p>
          `,function (err) {
              if (err) throw err
            }
          
          ) 
    
        }
    
        else {
    
          fs.appendFile(`./transcripts/transcript-${message.channel.id}.html`, `
          </p><p class="pt-2"></p><hr class="bg-dark"></hr></div></div></div><div class="container-fluid bg-light text-black"><div class="row w-50 pt-2 mx-auto"><div class="col w-50"><img src="${message.author.displayAvatarURL()}" class="rounded-circle mr-1 float-left" alt="Profile Picture" width="30px"><h5>${message.author.username}</h5><p class="w-50"><p><br><div class='embedded'> <strong>Embedded Message</strong><br>${message.embeds[0].description}<br></p>
    
          `, function (err) {
              if (err) throw err
            }
    
          )  
    
        }
    }

    let prefix = '!'
    let messageArray = message.content.split(" ")
    let cmd = messageArray[0]
    let args = messageArray.slice(1)

    let commands = client.commands.get(cmd.slice(prefix.length)) || client.commands.get(client.aliases.get(cmd.slice(prefix.length)));
    if(commands) {
        if(!message.content.startsWith(prefix)) return
        commands.run(client, message, args, prefix);
    }

    if(message.content.includes(client.user.id)){
      message.channel.send(`Mijn prefix is: \`${prefix}\``)
    }

})
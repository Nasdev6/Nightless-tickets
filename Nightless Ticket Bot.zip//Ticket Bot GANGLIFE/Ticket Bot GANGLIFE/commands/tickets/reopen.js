const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args, prefix) => {

    if(db.get(`ticketApproved_${message.channel.id}`) != true){
        const failedEmbed = new Discord.MessageEmbed()
            .setDescription(`U kunt deze opdracht alleen uitvoeren in een **Ticketkanaal**!`)
            .setColor("#DD0000")
        return message.reply({ embeds: [failedEmbed] })
    }

    message.delete()

    const user = client.users.cache.find(x => x.id === message.channel.topic)
    if(user === undefined) return

    message.channel.permissionOverwrites.create(user.id, {VIEW_CHANNEL: true, SEND_MESSAGES: true, ATTACH_FILES: true})
    
    const succesEmbed = new Discord.MessageEmbed()
        .setAuthor(`Ticket heropend`, message.guild.iconURL({ dynamic: true }))
        .setDescription(`Beste **${user.username}** uw ticket is heropend door het **Staff-Team**!`)
        .setColor("#DD0000")
        .setFooter("StayLife - Since 2022 © Alle rechten voorbehouden")
        .setTimestamp()
    message.channel.send({ embeds: [succesEmbed] })

    db.set(`ticket_${message.channel.topic}`, true)    

}

module.exports.help = {
    name: 'reopen',
    aliases: []
}
const Discord = require('discord.js');

module.exports.run = async (client, message, args, prefix) => {

    message.delete()

    const panel1 = new Discord.MessageEmbed()
        .setAuthor(`Ticket Support`, message.guild.iconURL({ dynamic: true }))
        .setDescription(`
Beste burgers van Staylife Combat, Klik op de meest gerelateerde knop onder dit bericht om een ticket te maken!

**Beschikbare Categorieën:**
> :person_raising_hand: - Algemene Vragen (Refunds, Klachten, Overige Dingen)
> :open_file_folder: - Unban Aanvraag
> 🛒 - Doneren
`)
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setColor("#8400b9")
        .setFooter("StayLife - Since 2022 © Alle rechten voorbehouden")
    
    const row1 = new Discord.MessageActionRow()
        .addComponents(
            new Discord.MessageButton()
                .setCustomId('category1')
                .setStyle('PRIMARY')
                .setLabel('Algemene Vragen')
                .setEmoji('📩'),

            new Discord.MessageButton()
                .setCustomId('category2')
                .setStyle('SECONDARY')
                .setLabel('Refund Aanvraag')
                .setEmoji('🔙'),

            new Discord.MessageButton()
                .setCustomId('category3')
                .setStyle('SECONDARY')
                .setLabel('Unban Aanvraag')
                .setEmoji('📂'),

            new Discord.MessageButton()
                .setCustomId('category4')
                .setStyle('SECONDARY')
                .setLabel('Donaties')
                .setEmoji('🛒')
                );

        message.channel.send({ embeds: [panel1], components: [row1] })
    

}

module.exports.help = {
    name: 'ticketpanel',
    aliases: []
}
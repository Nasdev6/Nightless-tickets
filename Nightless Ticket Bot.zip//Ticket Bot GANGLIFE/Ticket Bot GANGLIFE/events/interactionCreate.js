const Discord = require('discord.js');
const { MessageEmbed, MessageAttachment, MessageActionRow, MessageButton, Collection } = require(`discord.js`);
const db = require('quick.db');
const client = require("../index").client
const { Permissions } = require('discord.js');
const moment = require('moment');

const fs = require('fs')

client.on('interactionCreate', async (inter, interaction) => {

    if(inter.isCommand()){
        let slashCmds = client.SlashCmds.get(inter.commandName)
        if(slashCmds) slashCmds.run(client, inter)
    }

    if(inter.isContextMenu()){
        let slashCmds = client.SlashCmds.get(inter.commandName)
        if(slashCmds) slashCmds.run(inter)
    
    }

    if(inter.isButton()){
//        ALGEMENE VRAGEN
        if(inter.customId === "category1"){

            if(db.get(`ticket_${inter.user.id}`) === true){
                const alreadyOpen = new Discord.MessageEmbed()
                    .setDescription(`Je hebt momenteel al een ticket open staan!\nSluit a.u.b. voordat je een nieuwe opent!`)
                    .setColor("#8400b9")
                return await inter.reply({ embeds: [alreadyOpen], ephemeral: true })
            }
        
            const everyoneRole = inter.guild.roles.cache.find(x => x.name === "@everyone").id;
            inter.guild.channels.create(`ticket-${inter.user.username}`, { type: 'text', permissionOverwrites: [
                {
                    id: everyoneRole,
                    deny: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES]
                },
                {
                    id: inter.user.id,
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                },
                {
                    id: '955202000226754603', // vul hier het role id in die moet worden toegevoegd aan de tickets
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                }
            ], topic: inter.user.id, parent: '955208953199988736' /*Vul hier het categorie ID in waar het ticket moet worden geopend.*/}).then(async c => {
        
                fs.appendFile(`./transcripts/transcript-${c.id}.html`, `
                
<!doctype html>
<html lang="en">
<head>  <title>StayLife - Transcript</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://rimpllee.pro/ticket-transcripts/transcripts.css">
</head>
<body>
<header>
<div class="container-fluid bg-dark text-white text-center"><div class="row pt-2"><div class="col">
<h3>StayLife - Ticket Transcript</h3>
<p><small>Wie heeft de ticket aangemaakt?: ${inter.user.tag}<br>
Wat was de naam van de ticket?: ${c.name}<br>
Wanneer was de ticket aangemaakt?: ${moment().format('LLL')}
</p></small>
</div></div></div>
</header>
                `, function (err) {
                    if (err) throw err;
                });
        
                const openEmbed = new Discord.MessageEmbed()
                    .setDescription(`Uw ticket is succesvol geopend!\nU kunt het hier bekijken! ${c}`)
                    .setColor("#8400b9")
                await inter.reply({ embeds: [openEmbed], ephemeral: true})
        
                        const row = new MessageActionRow()
                                .addComponents(
                                    new MessageButton()
                                        .setCustomId('archiveticket')
                                        .setLabel('🔒 Sluit De Ticket')
                                        .setStyle('SECONDARY'),
                                )
                
                const thanksEmbed = new Discord.MessageEmbed()
                    .setColor("#8400b9")
                    .setAuthor(`${inter.guild.name} Tickets`, inter.guild.iconURL())
                    .setDescription(`Beste ${inter.user} Bedankt dat je contact hebt opgenomen met het **Support Team** van **${inter.guild.name}**! 📹\n\nWilt u uw probleem of vraag even uitleggen zodat wij u zo snel en goed mogelijk kunnen helpen!`)
                    .addField(`Ticket Maker:`, `${inter.user}`, true)
           	     	.setFooter("StayLife - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            	  	.setTimestamp()
          		    .setColor("#8400b9")
                    .setThumbnail(inter.guild.iconURL({ dynamic: true }))
                    c.send({ content: `${inter.user}`, embeds: [thanksEmbed], components: [row] })
                
                               /*Vul hier het rol id in die moet worden getagd bij het openen van een ticket.*/

                    db.set(`ticketApproved_${c.id}`, true)
                    db.set(`ticket_${inter.user.id}`, true)
        
            });
        
        }


//        REFUND AANVRAAG
        else if(inter.customId === "category2"){

            if(db.get(`ticket_${inter.user.id}`) === true){
                const alreadyOpen = new Discord.MessageEmbed()
                    .setDescription(`Je hebt momenteel al een ticket open staan!\nSluit a.u.b. voordat je een nieuwe opent!`)
                    .setColor("#8400b9")
                return await inter.reply({ embeds: [alreadyOpen], ephemeral: true })
            }
        
            const everyoneRole = inter.guild.roles.cache.find(x => x.name === "@everyone").id;
            inter.guild.channels.create(`refund-${inter.user.username}`, { type: 'text', permissionOverwrites: [
                {
                    id: everyoneRole,
                    deny: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES]
                },
                {
                    id: inter.user.id,
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                },
                {
                    id: '955202000226754603', // vul hier het role id in die moet worden toegevoegd aan de tickets
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                }
            ], topic: inter.user.id, parent: '955208981914202173' /*Vul hier het categorie ID in waar het ticket moet worden geopend.*/}).then(async c => {
        
                fs.appendFile(`./transcripts/transcript-${c.id}.html`, `
                
<!doctype html>
<html lang="en">
<head>  <title>StayLife - Transcript</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://rimpllee.pro/ticket-transcripts/transcripts.css">
</head>
<body>
<header>
<div class="container-fluid bg-dark text-white text-center"><div class="row pt-2"><div class="col">
<h3>StayLife - Ticket Transcript</h3>
<p><small>Wie heeft de ticket aangemaakt?: ${inter.user.tag}<br>
Wat was de naam van de ticket?: ${c.name}<br>
Wanneer was de ticket aangemaakt?: ${moment().format('LLL')}
</p></small>
</div></div></div>
</header>
                `, function (err) {
                    if (err) throw err;
                });
        
                const openEmbed = new Discord.MessageEmbed()
                    .setDescription(`Uw ticket is succesvol geopend!\nU kunt het hier bekijken! ${c}`)
                    .setColor("#8400b9")
                await inter.reply({ embeds: [openEmbed], ephemeral: true})
        
                        const row = new MessageActionRow()
                                .addComponents(
                                    new MessageButton()
                                        .setCustomId('archiveticket')
                                        .setLabel('🔒 Sluit De Ticket')
                                        .setStyle('SECONDARY'),
                                )
                
                const thanksEmbed = new Discord.MessageEmbed()
                    .setColor("#8400b9")
                    .setAuthor(`${inter.guild.name} Tickets`, inter.guild.iconURL())
                    .setDescription(`Beste ${inter.user} Bedankt dat je contact hebt opgenomen met het **Support Team** van **${inter.guild.name}**! 📹\n\nWilt u uw probleem of vraag even uitleggen zodat wij u zo snel en goed mogelijk kunnen helpen!`)
                    .addField(`Ticket Maker:`, `${inter.user}`, true)
           	     	.setFooter("StayLife - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            	  	.setTimestamp()
          		    .setColor("#8400b9")
                    .setThumbnail(inter.guild.iconURL({ dynamic: true }))
                    c.send({ content: `${inter.user}`, embeds: [thanksEmbed], components: [row] })
                
                               /*Vul hier het rol id in die moet worden getagd bij het openen van een ticket.*/

                    db.set(`ticketApproved_${c.id}`, true)
                    db.set(`ticket_${inter.user.id}`, true)
        
            });
        
        }

//        UNBAN AANVRAAG
        else if(inter.customId === "category3"){

            if(db.get(`ticket_${inter.user.id}`) === true){
                const alreadyOpen = new Discord.MessageEmbed()
                    .setDescription(`Je hebt momenteel al een ticket open staan!\nSluit a.u.b. voordat je een nieuwe opent!`)
                    .setColor("#8400b9")
                return await inter.reply({ embeds: [alreadyOpen], ephemeral: true })
            }
        
            const everyoneRole = inter.guild.roles.cache.find(x => x.name === "@everyone").id;
            inter.guild.channels.create(`unban-${inter.user.username}`, { type: 'text', permissionOverwrites: [
                {
                    id: everyoneRole,
                    deny: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES]
                },
                {
                    id: inter.user.id,
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                },
                {
                    id: '955202000226754603', // vul hier het role id in die moet worden toegevoegd aan de tickets
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                }
            ], topic: inter.user.id, parent: '955208997810630708' /*Vul hier het categorie ID in waar het ticket moet worden geopend.*/}).then(async c => {
        
                fs.appendFile(`./transcripts/transcript-${c.id}.html`, `
                
<!doctype html>
<html lang="en">
<head>  <title>StayLife - Transcript</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://rimpllee.pro/ticket-transcripts/transcripts.css">
</head>
<body>
<header>
<div class="container-fluid bg-dark text-white text-center"><div class="row pt-2"><div class="col">
<h3>StayLife - Ticket Transcript</h3>
<p><small>Wie heeft de ticket aangemaakt?: ${inter.user.tag}<br>
Wat was de naam van de ticket?: ${c.name}<br>
Wanneer was de ticket aangemaakt?: ${moment().format('LLL')}
</p></small>
</div></div></div>
</header>
                `, function (err) {
                    if (err) throw err;
                });
        
                const openEmbed = new Discord.MessageEmbed()
                    .setDescription(`Uw ticket is succesvol geopend!\nU kunt het hier bekijken! ${c}`)
                    .setColor("#8400b9")
                await inter.reply({ embeds: [openEmbed], ephemeral: true})
        
                        const row = new MessageActionRow()
                                .addComponents(
                                    new MessageButton()
                                        .setCustomId('archiveticket')
                                        .setLabel('🔒 Sluit De Ticket')
                                        .setStyle('SECONDARY'),
                                )
                
                const thanksEmbed = new Discord.MessageEmbed()
                    .setColor("#8400b9")
                    .setAuthor(`${inter.guild.name} Tickets`, inter.guild.iconURL())
                    .setDescription(`Beste ${inter.user} Bedankt dat je contact hebt opgenomen met het **Support Team** van **${inter.guild.name}**! 📹\n\nWilt u uw probleem of vraag even uitleggen zodat wij u zo snel en goed mogelijk kunnen helpen!`)
                    .addField(`Ticket Maker:`, `${inter.user}`, true)
           	     	.setFooter("StayLife - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            	  	.setTimestamp()
          		    .setColor("#8400b9")
                    .setThumbnail(inter.guild.iconURL({ dynamic: true }))
                    c.send({ content: `${inter.user}`, embeds: [thanksEmbed], components: [row] })
                
                               /*Vul hier het rol id in die moet worden getagd bij het openen van een ticket.*/

                    db.set(`ticketApproved_${c.id}`, true)
                    db.set(`ticket_${inter.user.id}`, true)
        
            });
        
        }


//        DONATIES
        else if(inter.customId === "category4"){

            if(db.get(`ticket_${inter.user.id}`) === true){
                const alreadyOpen = new Discord.MessageEmbed()
                    .setDescription(`Je hebt momenteel al een ticket open staan!\nSluit a.u.b. voordat je een nieuwe opent!`)
                    .setColor("#8400b9")
                return await inter.reply({ embeds: [alreadyOpen], ephemeral: true })
            }
        
            const everyoneRole = inter.guild.roles.cache.find(x => x.name === "@everyone").id;
            inter.guild.channels.create(`donatie-${inter.user.username}`, { type: 'text', permissionOverwrites: [
                {
                    id: everyoneRole,
                    deny: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES]
                },
                {
                    id: inter.user.id,
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                },
                {
                    id: '955202000226754603', // vul hier het role id in die moet worden toegevoegd aan de tickets
                    allow: [Permissions.FLAGS.VIEW_CHANNEL, Permissions.FLAGS.SEND_MESSAGES, Permissions.FLAGS.ATTACH_FILES]
                }
            ], topic: inter.user.id, parent: '955209026554179585' /*Vul hier het categorie ID in waar het ticket moet worden geopend.*/}).then(async c => {
        
                fs.appendFile(`./transcripts/transcript-${c.id}.html`, `
                
<!doctype html>
<html lang="en">
<head>  <title>StayLife - Transcript</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <link rel="stylesheet" href="https://rimpllee.pro/ticket-transcripts/transcripts.css">
</head>
<body>
<header>
<div class="container-fluid bg-dark text-white text-center"><div class="row pt-2"><div class="col">
<h3>StayLife - Ticket Transcript</h3>
<p><small>Wie heeft de ticket aangemaakt?: ${inter.user.tag}<br>
Wat was de naam van de ticket?: ${c.name}<br>
Wanneer was de ticket aangemaakt?: ${moment().format('LLL')}
</p></small>
</div></div></div>
</header>
                `, function (err) {
                    if (err) throw err;
                });
        
                const openEmbed = new Discord.MessageEmbed()
                    .setDescription(`Uw ticket is succesvol geopend!\nU kunt het hier bekijken! ${c}`)
                    .setColor("#8400b9")
                await inter.reply({ embeds: [openEmbed], ephemeral: true})
        
                        const row = new MessageActionRow()
                                .addComponents(
                                    new MessageButton()
                                        .setCustomId('archiveticket')
                                        .setLabel('🔒 Sluit De Ticket')
                                        .setStyle('SECONDARY'),
                                )
                
                const thanksEmbed = new Discord.MessageEmbed()
                    .setColor("#v")
                    .setAuthor(`${inter.guild.name} Tickets`, inter.guild.iconURL())
                    .setDescription(`Beste ${inter.user} Bedankt dat je contact hebt opgenomen met het **Support Team** van **${inter.guild.name}**! 📹\n\nWilt u uw probleem of vraag even uitleggen zodat wij u zo snel en goed mogelijk kunnen helpen!`)
                    .addField(`Ticket Maker:`, `${inter.user}`, true)
           	     	.setFooter("StayLife - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            	  	.setTimestamp()
          		    .setColor("#8400b9")
                    .setThumbnail(inter.guild.iconURL({ dynamic: true }))
                    c.send({ content: `${inter.user}`, embeds: [thanksEmbed], components: [row] })
                
                               /*Vul hier het rol id in die moet worden getagd bij het openen van een ticket.*/

                    db.set(`ticketApproved_${c.id}`, true)
                    db.set(`ticket_${inter.user.id}`, true)
        
            });
        
        }




        else if(inter.customId === 'archiveticket') {
                const member = inter.member;
    
   const closeReason = "Er is geen reden opgegeven"
    if(!closeReason) return inter.message.channel.send("Geef een close reden op!");
    
    const user = client.users.cache.find(x => x.id === inter.message.channel.topic)
    if(user === undefined) return setTimeout(() => {inter.message.channel.delete()}, 5000)
    
    const succesEmbed = new Discord.MessageEmbed()
        .setAuthor(`Ticket gesloten`, inter.message.guild.iconURL({ dynamic: true }))
        .setDescription(`Dit ticket is succesvol gesloten door: **${inter.message.author}**!\n**${user.username}** ontvangt een transcript in zijn DM als hij het open heeft staan!\n\nOver \` 5 \` seconden wordt dit kanaal verwijderd!`)
            .setFooter("StayLife - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            .setTimestamp()
            .setColor("#8400b9");
    inter.message.channel.send({ embeds: [succesEmbed] })

    db.delete(`ticketApproved_${inter.message.channel.id}`)
    db.delete(`ticket_${inter.message.channel.topic}`)    

    setTimeout(() => {
        inter.message.channel.delete()
    }, 5000)

    
        const transcriptEmbed = new Discord.MessageEmbed()
            .setTitle(`Ticket Gesloten`)
            .setThumbnail(client.user.displayAvatarURL())
            .setDescription(`Goedendag ${member},\n\nWij hebben besloten om uw ticket in de Cxsh Development discord server te sluiten, de reden van de sluiting van uw ticket staat hieronder vermeld.\n\n**Wij hebben uw ticket afgesloten met als reden:** ${closeReason}\n\nHeeft u toch nog een vraag of heeft een support member het verkeerd gezien en mocht de ticket niet gesloten worden? Dan is het mogelijk om een nieuwe ticket aan te maken in <#938047324540764201>.\n\nWij willen u nog een hele fijne dag wensen.\nMet vriendelijke groet,\n\nStayLife Roleplay - Ticket Systeem`)
            .setFooter("Cxsh Development - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            .setTimestamp()
            .setColor("#8400b9");


            
    user.send({ embeds: [transcriptEmbed], files: [`./transcripts/transcript-${inter.message.channel.id}.html`] }).catch(() => {});
       const transcriptLogChannel = inter.client.channels.cache.get("955503371563991070")
           const transcriptLogEmbed = new Discord.MessageEmbed()
            .setTitle(`Ticket Gesloten`)
            .setThumbnail(client.user.displayAvatarURL())
            .setDescription(`**Gesloten Door:** ${inter.member}\n**Reden:** ${closeReason}`)
            .setFooter("Cxsh Development - Since 2022 © Alle rechten voorbehouden", client.user.displayAvatarURL())
            .setTimestamp()
            .setColor("#8400b9");

        transcriptLogChannel.send({ embeds: [transcriptLogEmbed], files: [`./transcripts/transcript-${inter.message.channel.id}.html`] }).catch(() => {});
inter.message.channel

        } 

    }

})
const Discord = require('discord.js');
const db = require('quick.db');
const client = require("../index").client
const { Permissions } = require('discord.js');
const moment = require('moment');

const fs = require('fs')

client.on('channelDelete', async channel => {

    if(db.get(`ticketApproved_${channel.id}`) === true){

        db.delete(`ticketApproved_${channel.id}`)
        db.delete(`ticket_${channel.topic}`)

        const getUser = client.users.cache.find(x => x.id === channel.topic)
        if(getUser === undefined) return
        getUser.send({ files: [`./transcripts/transcript-${channel.id}.html`] }).catch(() => {});

    }

})
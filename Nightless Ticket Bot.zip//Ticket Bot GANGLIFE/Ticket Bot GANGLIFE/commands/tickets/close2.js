const Discord = require('discord.js');
const db = require('quick.db')

module.exports.run = async (client, message, args, prefix) => {

    if(db.get(`ticketApproved_${message.channel.id}`) != true){
        const failedEmbed = new Discord.MessageEmbed()
            .setDescription(`U kunt deze opdracht alleen uitvoeren in een **Ticketkanaal**!`)
            .setColor("#DD0000")
        return message.reply({ embeds: [failedEmbed] })
    }

    message.delete()

    const user = client.users.cache.find(x => x.id === message.channel.topic)
    if(user === undefined) return setTimeout(() => {message.channel.delete()}, 5000)
    
    const succesEmbed = new Discord.MessageEmbed()
        .setAuthor(`Ticket gesloten`, message.guild.iconURL({ dynamic: true }))
        .setDescription(`Dit ticket is succesvol gesloten door: **${message.author}**!\n**${user.username}** ontvangt een transcript in zijn DM als hij het open heeft staan!\n\nOver \` 5 \` seconden wordt dit kanaal verwijderd!`)
        .setColor("#DD0000")
        .setFooter("StayLife - Since 2022 © Alle rechten voorbehouden")
        .setTimestamp()
    message.channel.send({ embeds: [succesEmbed] })

    db.delete(`ticketApproved_${message.channel.id}`)
    db.delete(`ticket_${message.channel.topic}`)    

    setTimeout(() => {
        message.channel.delete()
    }, 5000)

    user.send({ files: [`./transcripts/transcript-${message.channel.id}.html`] }).catch(() => {});
    

}

module.exports.help = {
    name: 'close2',
    aliases: []
}